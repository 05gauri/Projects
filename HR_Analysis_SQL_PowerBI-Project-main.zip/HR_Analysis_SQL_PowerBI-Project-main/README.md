# HR_Analysis_SQL_PowerBI-Project

This project is a HR analytics dashboard built using SQL and Power BI. The dashboard provides a real-time view of key HR metrics, such as employee turnover, headcount, and diversity.
# Requirements
SQL Server

Power BI

The HR Analytics dashboard can be used by HR professionals and managers to track key HR metrics, identify trends, and make data-driven decisions. The dashboard can also be used by employees to get insights into their own performance and the company as a whole.
